## v1.1.0:

* [COOK-1098] - support amazon linux
* [COOK-1149] - support Mac OS X
* [COOK-1296] - allow for compile-time installation of packages
  through an attribute (see README)

## v1.0.2:

* [COOK-1098] - Add Amazon Linux platform support
* [COOK-1149] - Add OS X platform support
