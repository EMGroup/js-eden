if (this['console'] === undefined) {
	console = {
		log:function() {},
		debug:function() {},
		error:function() {}
	};
}
